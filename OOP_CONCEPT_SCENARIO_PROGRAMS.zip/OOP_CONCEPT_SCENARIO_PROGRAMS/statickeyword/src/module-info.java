module statickeyword {
}
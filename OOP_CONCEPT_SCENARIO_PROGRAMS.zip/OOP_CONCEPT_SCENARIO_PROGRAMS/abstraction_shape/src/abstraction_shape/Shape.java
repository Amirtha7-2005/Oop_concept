package abstraction_shape;

abstract class Shape {
	String shapeName;
	abstract double calculateArea();
	public void displayShape() {
		System.out.println("Shape: "+shapeName);
	}
	public static void main(String[] args) {
		Shape s;
		s=new Circle(7);
		s.displayShape();
		System.out.println("Area of circle: "+s.calculateArea());
		s=new Rectangle(2,4);
		s.displayShape();
		System.out.println("Area of rectangle: "+s.calculateArea());
	}

}

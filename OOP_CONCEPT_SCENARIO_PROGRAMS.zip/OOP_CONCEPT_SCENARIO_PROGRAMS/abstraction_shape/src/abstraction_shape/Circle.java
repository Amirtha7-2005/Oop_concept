package abstraction_shape;

public class Circle extends Shape{
	double radius;
	Circle(double radius){
		this.radius=radius;
		shapeName="circle";
	}
	public double calculateArea() {
		return 3.14*radius*radius;
	}

}

package constructor_bank;

public class BankAccount {
	int accountNumber;
	double balance;
	BankAccount(){
		balance=0;
		accountNumber=0;
	}
	BankAccount(int accNo,double initialBalance){
		accountNumber=accNo;
		balance=initialBalance;
	}
	public void deposit(double amount)
	{
		balance+=amount;
		System.out.println("Deposited");
		System.out.println("Current balance: "+balance);
	} 
	public void withdraw(double amount){
		if(balance>=amount){
			balance=balance-amount;
			System.out.println("Amount withdrawal: "+amount);
		}	
		else{
			System.out.println("Insufficient balance");
			}
		}
	public void displayAccount()
	{
		System.out.println("account number: "+accountNumber);
		System.out.println("Balance: "+balance);
	}
	public static void main(String[]args){
		BankAccount acc1= new BankAccount();
		acc1.displayAccount();
		BankAccount acc2= new BankAccount(100,1010);
		acc2.deposit(2000);
		acc2.withdraw(300);
		acc2.displayAccount();
	}
}
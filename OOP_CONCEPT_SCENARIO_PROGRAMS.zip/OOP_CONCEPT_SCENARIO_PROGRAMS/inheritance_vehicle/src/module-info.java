module inheritance_vehicle {
}
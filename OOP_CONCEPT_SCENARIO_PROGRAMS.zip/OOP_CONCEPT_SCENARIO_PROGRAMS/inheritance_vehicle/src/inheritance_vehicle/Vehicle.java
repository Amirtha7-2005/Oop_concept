package inheritance_vehicle;

public class Vehicle {
	String brand;
	int speed;	
	public void start(){
		System.out.println("Vehicle started");
	}
	public void stop(){
		System.out.println("Vehicle stopped");
	}
}

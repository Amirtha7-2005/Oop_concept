module encapsulation_bank_mgmt {
}
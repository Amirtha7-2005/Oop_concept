package inteface_smarthome;

public class SmartLight implements SmartDevice{
	

	public static void main(String[] args) {
		SmartDevice sl=new SmartLight();
		sl.turnOn();
		sl.turnOff();
	}

	@Override
	public void turnOn() {
		System.out.println("Light turned on");
	}

	@Override
	public void turnOff() {
		System.out.println("Light turned off");
	}
}

package inteface_smarthome;

public class SmartFan implements SmartDevice{

	public static void main(String[] args) {
		SmartDevice sf=new SmartFan();
		sf.turnOn();
		sf.turnOff();
	}

	@Override
	public void turnOn() {
		System.out.println("Fan turned on");
	}

	@Override
	public void turnOff() {
		System.out.println("Fan turned off");
	}
}

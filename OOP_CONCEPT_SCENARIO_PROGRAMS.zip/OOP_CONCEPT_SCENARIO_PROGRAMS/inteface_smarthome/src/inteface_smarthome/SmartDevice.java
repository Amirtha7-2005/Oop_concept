package inteface_smarthome;

public interface SmartDevice {
	public void turnOn();
	public void turnOff();
}

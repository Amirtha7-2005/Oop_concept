package accessmodifier_student;

public class Student {
	public String name;
	private int marks;
	protected String grade;
	int rollNumber;
	public void setMarks(int marks) {
		if(marks>=0 && marks<=100) {
			this.marks=marks;
			
		}
	}
	private void calculateGrade() {
		if(marks>=91 && marks<=100) {
			grade="A";
		}
		else if(marks>=81 && marks<=90) {
			grade="B";
		}
		else if(marks>=61 && marks<=80) {
			grade="C";
		}
		else if(marks>=51 && marks<=60) {
			grade="D";
		}
		else {
			grade="F";
		}
	}
	public String getGrade() {
		return grade;
	}
	public void displayBasicInfo() {
		System.out.println("Name: "+name);
		System.out.println("Roll No. : "+rollNumber);
	}
	public static void main(String[] args) {
		Student s=new Student();
		s.name="Amirtha";
		s.rollNumber=17;
		s.setMarks(90);
		s.calculateGrade();
		s.displayBasicInfo();
		System.out.println("yur grade is "+s.getGrade());

	}

}


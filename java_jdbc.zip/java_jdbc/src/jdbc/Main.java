package jdbc;
import java.sql.*;
public class Main {
//step-1 importing the package
	public static void main(String[] args) throws SQLException {
		String url="jdbc:mysql://localhost:3306/sample";
		String user="root";
		String pass="root";
		//step-2 establish connection
		Connection c=DriverManager.getConnection(url,user,pass);
		String query="Select * from student";
		//step-3 create statement
		Statement st=c.createStatement();
		ResultSet rs=st.executeQuery(query);
		while(rs.next()) {
			int a=rs.getInt(1);
			String n=rs.getString(2);
			int ag=rs.getInt(3);
			//step-4 executing the result
			System.out.println(a+" "+n+" "+ag);
		}
	}
}

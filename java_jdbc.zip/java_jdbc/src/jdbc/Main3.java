package jdbc;
import java.sql.*;
	public class Main3 {
	//step-1 import package
		public static void main(String[] args) throws SQLException{
			//step-2 establish connection
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","root");
			String query="insert into student values(105,'jay',29)";
			//step-3 create statement
			Statement st=c.createStatement();
			st.executeUpdate(query);

		}
	}
}

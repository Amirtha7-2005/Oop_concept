package jdbc;
import java.sql.*;
public class Main4 {
	public static void main(String[] args) throws SQLException {
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","root");
		String query="insert into student values(?,?,?)";
		PreparedStatement ps=c.prepareStatement(query);
		ps.setInt(1, 106);
		ps.setString(2, "ryan");
		ps.setInt(3, 22);
		int a=ps.executeUpdate();
		if(a>0) {
			System.out.println("Row Inserted Successfully");
		}
		else {
			System.out.println("Not Inserted");
		}
	}
}
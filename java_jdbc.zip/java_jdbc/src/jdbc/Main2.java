package jdbc;
import java.sql.*;
public class Main2 {


		public static void main(String[] args) throws SQLException {
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","root");
			String query="Select * from student";
			//step-3 create statement
			Statement st=c.createStatement();
			ResultSet rs=st.executeQuery(query);
			while(rs.next()) {
				int a=rs.getInt(1);
				String n=rs.getString(2);
				int ag=rs.getInt(3);
				System.out.println(a+" "+n+" "+ag);
			}
		}

	}
}

package sample;
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;




@WebServlet("/Main")
public class Main extends HttpServlet {
		public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			res.setContentType("text/html");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","root");
			String q="insert into users(name,phone,email,pass) values(?,?,?,?)";
			PreparedStatement ps=c.prepareStatement(q);
			
			String name=req.getParameter("name");
			String phone=req.getParameter("phone");
			String email=req.getParameter("email");
			String pass=req.getParameter("pass");
			PrintWriter out=res.getWriter();

			
			ps.setString(1,name);
			ps.setString(2,phone);
			ps.setString(3,email);
			ps.setString(4,pass);
			
			int r=ps.executeUpdate();
			if (r > 0) {
			    out.println("<!DOCTYPE html>");
			    out.println("<html><body>");
			    out.println("<h2 style='color:green'>Registration Successful</h2>");
			    out.println("</body></html>");
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}